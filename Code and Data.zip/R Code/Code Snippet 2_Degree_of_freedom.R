#==============================================================================
# Student's T Copula - Degree of Freedom
#==============================================================================

install.packages("tiger")
library(tiger)
library(readxl)
spread_data=as.data.frame(KT_Corr_input)
spread_data$V1=to.uniform(spread_data$V1,val=NA)
spread_data$V2=to.uniform(spread_data$V2,val=NA)
spread_data$V3=to.uniform(spread_data$V3,val=NA)
spread_data$V4=to.uniform(spread_data$V4,val=NA)
spread_data$V5=to.uniform(spread_data$V5,val=NA)

# Define Student's t copula density function
T_density = function (U,v,Sigma) {
  n = length(U)
  
  First_Part = (1/sqrt(det(Sigma)))*(gamma((v+n)/2)/gamma(v/2))*(gamma(v/2)/gamma((v+1)/2))^n
  
  num = (1 + ((qt(t(U), df=v) %*% solve(Sigma) %*% qt(U, df=v))/v))^(-(v+n)/2)
  denom = 1
  for (i in seq(1,n)) {
    denom = denom * (1+((qt(U[i],df=v)^2)/v))^(-(v+1)/2) 
  } 
  Last_Part = num/denom
  
  return(First_Part*Last_Part)
}

# Define Log likelihood function 
MLE = function(U_matrix,v,Correlation) {
  value = 0
  for (i in seq(1,nrow(U_matrix))) {
    value = value + log(T_density(as.matrix(U_matrix[i,]),v,Correlation))
  }
  return(value)
}

Spread_matrix=data.matrix(spread_data, rownames.force = NA)
Spread_matrix = Spread_matrix[(Spread_matrix[,1]!=1.0 & Spread_matrix[,2]!=1.0 & Spread_matrix[,3]!=1.0 & Spread_matrix[,4]!=1.0 & Spread_matrix[,5]!=1.0) &
                                !is.na(Spread_matrix[,1]) & !is.na(Spread_matrix[,2]) & !is.na(Spread_matrix[,3]) & !is.na(Spread_matrix[,4]) & !is.na(Spread_matrix[,5]),]

# Plot of the log-likelihood function
v_list = seq(1,20,by=1)
loglikelihood = sapply(v_list,MLE,U_matrix=Spread_matrix,Correlation=KT_Correlation_Matrix_Linear)
plot(v_list,loglikelihood,type="l",xlab="DF",ylab="Log Likelihood",log="y")
loglikelihood

# Maximum Likelihood estimation to find degree of freedom
# optimization routine to compute degree of freedom for student t
degree_freedom = round(optimize(MLE, U_matrix = Spread_matrix, Correlation=KT_Correlation_Matrix_Linear, interval=c(1, 50),maximum=TRUE)$maximum)
degree_freedom

