####Initialisation
No_of_iterations=100000
Recovery=.4

##################
##### Quasi and Pseudo random number generation functions####
##################

###Sobol implementation
install.packages("randtoolbox")

Sobol_function = function (number_of_iteration){
library(randtoolbox)
data_Sobol=sobol(number_of_iteration, dim = 5, init = TRUE, scrambling = 0, seed = 100, normal = TRUE,
      mixed = FALSE, method="Fortran", mexp = 19937)
return(data_Sobol)
}

###Pseudo Random Number implementation
Random_number_function = function (number_of_iteration){
  data1=rnorm(number_of_iteration)
  data2=rnorm(number_of_iteration)
  data3=rnorm(number_of_iteration)
  data4=rnorm(number_of_iteration)
  data5=rnorm(number_of_iteration)
  
  data_Random=cbind(data1,data2,data3,data4,data5)  

  return(data_Random)
}


#==============================================================================
# Generate Chi-Square Value
#==============================================================================
ChiSq_function= function(no_of_iteration,degree_of_freedom){
ChiSq <-as.data.frame(matrix(nrow=no_of_iteration,ncol=5))
for (i in seq(1,5)) {
  set.seed(100)
  ChiSq[i] = rchisq(no_of_iteration,degree_of_freedom,ncp=0) 
} 
return(ChiSq)
}

#------------------------------------
## Discount curve function
#------------------------------------
setwd("C:/Users/aviks/Documents/CQF/Final Project/Submission/Data/US treasury rates for discounting")
USD_Rates=read.csv("USD_Rates.csv",header=TRUE,sep=",")
plot(USD_Rates)
attach(USD_Rates)
fit<-lm(Rate~poly(Year,2,raw=TRUE))

discount_curve= function(Time){
  DF=0
  if (Time %in% c(1,2,3,4,5)){
    DF=1/(1+USD_Rates[Time,2])^Time
    }
  else {
    Rate_fitted=predict(fit,data.frame(Year=Time))
    DF=1/(1+unname(Rate_fitted))^Time
  }
  return(DF)
}


#==============================================================================
#  Spread Calculation
#==============================================================================
  
## Read the default time matrix as input
library(readxl)

library(Rfast)

# Define Spread Calculation function 

Fair_Spread = function(Default_time_matrix,Recov) {

 ## Check whether the simulated instances are in default 
    Default <-as.data.frame(matrix(nrow=nrow(Default_time_matrix),ncol=1))
 
  for (i in seq(1,nrow(Default_time_matrix))) {
    Default[i,1]=0
    Sum=0
    for (j in seq(1,ncol(Default_time_matrix))) {
    Sum=Sum+if(Default_time_matrix[i,j]!=999.0) {1} else {0}
    }
    Default[i,1]= Default[i,1]+Sum
  }

 
### Spread calculation for K=1 to K=5
    
    Prem_leg <-as.data.frame(matrix(nrow=nrow(Default_time_matrix),ncol=1))
    Default_leg <-as.data.frame(matrix(nrow=nrow(Default_time_matrix),ncol=1))
    Fair_spread_array <-as.data.frame(matrix(nrow=5,ncol=1))

    Recovery_rate=Recov
    
    for (K in seq(1,5)) {
      sum_prem_leg=0
      sum_default_leg=0  
      avg_prem_leg=0
      avg_default_leg=0
      
      for (i in seq(1,nrow(Default_time_matrix))) {
     ## Calculate the average for the premium leg
      
      if(Default[i,1]>=K){
        Prem_leg[i,1]=Rfast::nth(Default_time_matrix[i,],K,descending = FALSE)*discount_curve(Rfast::nth(Default_time_matrix[i,],K,descending = FALSE))
      } 
      else {
        Prem_leg[i,1]=discount_curve(1)*1+discount_curve(2)*1+discount_curve(3)*1+discount_curve(4)*1+discount_curve(5)*1
        }
      sum_prem_leg=sum_prem_leg+Prem_leg[i,1]
      
      
      ## Calculate the average for the default leg

      if(Default[i,1]>=K){
        Default_leg[i,1]=((1-Recovery_rate)/5)*discount_curve(Rfast::nth(Default_time_matrix[i,],K,descending = FALSE))
      } 
      else {
        Default_leg[i,1]=0
      }
      sum_default_leg=sum_default_leg+Default_leg[i,1]
      }
  avg_default_leg=sum_default_leg/nrow(Default_time_matrix)  
  avg_prem_leg=sum_prem_leg/nrow(Default_time_matrix)

  Fair_spread_array[K,1]=(avg_default_leg/avg_prem_leg)*10000    
  }       
return(Fair_spread_array)
}


####Read Input Credit Spreads
Credit_Spreads=read_excel(path=file.choose(), col_names = FALSE)

####Function to calculate Lambdas
Lambda_calculation = function(Spread_data,Recovery_rate) {
Implied_Surival_Prob= as.data.frame(matrix(nrow=5,ncol=5))
Lambda= as.data.frame(matrix(nrow=5,ncol=5))
Lambda_Cumulative= as.data.frame(matrix(nrow=5,ncol=5))

##Case 1: Implied survival probability for t=1
for (i in seq(1,5)) { 
  Implied_Surival_Prob[i,1]=(1-Recovery_rate)/(1-Recovery_rate+Spread_data[i,1]/10000)
  Lambda[i,1]=-log(Implied_Surival_Prob[i,1])
  Lambda_Cumulative[i,1]=Lambda[i,1]
  }

###Case 2: Implied survival probability for t=2 to t=5
First_Term= as.data.frame(matrix(nrow=5,ncol=4))
Second_Term= as.data.frame(matrix(nrow=5,ncol=4))
Third_Term= as.data.frame(matrix(nrow=5,ncol=4))
Fourth_Term= as.data.frame(matrix(nrow=5,ncol=4))
Sum=as.data.frame(matrix(nrow=5,ncol=4))
Quotient=as.data.frame(matrix(nrow=5,ncol=4))
Initial_Term=as.data.frame(matrix(nrow=5,ncol=4))
Last_Term=as.data.frame(matrix(nrow=5,ncol=4))


for (i in seq(1,5)) { 
  for (j in seq(1,4)) { 
    First_Term[i,j]=discount_curve(1)*((1-Recovery_rate)-(1-Recovery_rate+Spread_data[i,j+1]/10000)*Implied_Surival_Prob[i,1])
    if(j>=2){
      Second_Term[i,j]=discount_curve(2)*((1-Recovery_rate)*Implied_Surival_Prob[i,1]-(1-Recovery_rate+Spread_data[i,j+1]/10000)*Implied_Surival_Prob[i,2])
      } 
    else{
      Second_Term[i,j]=0
      }
    if(j>=3){
      Third_Term[i,j]=discount_curve(3)*((1-Recovery_rate)*Implied_Surival_Prob[i,2]-(1-Recovery_rate+Spread_data[i,j+1]/10000)*Implied_Surival_Prob[i,3])
    } 
    else{
      Third_Term[i,j]=0
    }
    if(j==4){
      Fourth_Term[i,j]=discount_curve(4)*((1-Recovery_rate)*Implied_Surival_Prob[i,3]-(1-Recovery_rate+Spread_data[i,j+1]/10000)*Implied_Surival_Prob[i,4])
    } 
    else{
      Fourth_Term[i,j]=0
    }
    Sum[i,j]=First_Term[i,j]+Second_Term[i,j]+Third_Term[i,j]+Fourth_Term[i,j]
    Quotient[i,j]=discount_curve(j+1)*(1-Recovery_rate+Spread_data[i,j+1]/10000)
    Initial_Term[i,j]=Sum[i,j]/Quotient[i,j]
    Last_Term[i,j]=(Implied_Surival_Prob[i,j]*(1-Recovery_rate))/(1-Recovery_rate+Spread_data[i,j+1]/10000)
    Implied_Surival_Prob[i,j+1]=Initial_Term[i,j]+Last_Term[i,j]
    Lambda[i,j+1]=-log(Implied_Surival_Prob[i,j+1]/Implied_Surival_Prob[i,j])
    Lambda_Cumulative[i,j+1]=Lambda[i,j+1]+Lambda_Cumulative[i,j]
    }
}
return(Lambda_Cumulative)
}

###Lambda Array
Lambda_array=Lambda_calculation(Credit_Spreads,Recovery)


###Tau Matrix- Gaussian-----------------------------------

Uniform_gaussian_function = function(sobol_data,correlation) {
Uniform_gaussian=pnorm(correlation %*% t(sobol_data))
return(t(Uniform_gaussian))
}

###Tau Matrix- Student T-----------------------------------

Uniform_studentt_function = function(sobol_data,ChiSq_data,correlation,degree_of_freedom) {
  
  Studentt_vector=as.data.frame(matrix(nrow=nrow(sobol_data),ncol=5)) 
  for (i in seq(1,nrow(sobol_data))) {  
    for (j in seq(1,5)) { 
      Studentt_vector[i,j]=(sobol_data[i,j]/sqrt(ChiSq_data[i,j]/degree_of_freedom))
    }
  }
  Uniform_studentt=pt(correlation %*% t(Studentt_vector),degree_of_freedom)
  return(t(Uniform_studentt))
}


#####Default Time----
default_time=function(uniform_distribution,Lambda) {
default_time= as.data.frame(matrix(nrow=nrow(uniform_distribution),ncol=ncol(uniform_distribution))) 
for (i in seq(1,nrow(uniform_distribution))) {  
  for (j in seq(1,ncol(uniform_distribution))) { 
    default_time[i,j]=999
    for (k in seq(1,ncol(Lambda))) { 
    if(k==0)  {
      if(abs(log(1-uniform_distribution[i,j]))<=Lambda[j,k]){default_time[i,j]=(k-0.5)}
    }
      else if ((abs(log(1-uniform_distribution[i,j]))<=Lambda[j,k])&(default_time[i,j]>(k-0.5))){
        default_time[i,j]=(k-0.5)
        }
      }
    }
  }
return(default_time)
}

##########
######Standard Normal data and Chi Square data for Monte Carlo Simulation####
###########
Sobol_data=Sobol_function(No_of_iterations)
Pseudo_random_data=Random_number_function(No_of_iterations)
Chi_Square=ChiSq_function(No_of_iterations,degree_freedom)

############
####Basket credit swap pricing
############

####Pricing of Credit Spread- Gaussian Copula
Uniform_gaussian=Uniform_gaussian_function(Sobol_data,t(Pearson_Corr.chol))
Tau_matrix_gaussian=default_time(Uniform_gaussian,Lambda_array)
Spread_Gaussian=Fair_Spread(as.matrix(Tau_matrix_gaussian),Recovery)
Spread_Gaussian

####Pricing of Credit Spread- T Copula

Uniform_studentt=Uniform_studentt_function(Sobol_data,Chi_Square,t(KT_Corr.chol),degree_freedom)
Tau_matrix_studentt=default_time(Uniform_studentt,Lambda_array)
Spread_StudentT=Fair_Spread(as.matrix(Tau_matrix_studentt),Recovery)
Spread_StudentT

############################
######Sensitivity Analysis
############################

#-------------------------------
##Sensitivity to correlation   
#-------------------------------
library(Matrix)
library(mbend)
spread_array=c(-.2,-.1,-.08,-.06,-.04,-.02,.02,.04,.06,.08,.1,.2,.3,.4)
Fair_spread_corr_sensitivity_gaussian <-as.data.frame(matrix(nrow=5,ncol=14))
Fair_spread_corr_sensitivity_studentt <-as.data.frame(matrix(nrow=5,ncol=14))
colnames(Fair_spread_corr_sensitivity_gaussian)=c("Corr:-.2","Corr:-.1","Corr:-.08","Corr:-.06","Corr:-.04","Corr:-.02","Corr:.02","Corr:.04","Corr:.06","Corr:.08","Corr:.1","Corr:.2","Corr:.3","Corr:.4")
colnames(Fair_spread_corr_sensitivity_studentt)=c("Corr:-.2","Corr:-.1","Corr:-.08","Corr:-.06","Corr:-.04","Corr:-.02","Corr:.02","Corr:.04","Corr:.06","Corr:.08","Corr:.1","Corr:.2","Corr:.3","Corr:.4")

for (i in seq(1,14)) {

##Gaussian Copula
Pearson_Correlation_Matrix_stressed=Pearson_Correlation_Matrix*(1+spread_array[i])
Pearson_Correlation_Matrix_stressed[Pearson_Correlation_Matrix_stressed>1]=1
Pearson_Correlation_Matrix_stressed[Pearson_Correlation_Matrix_stressed<-1]=-1
diag(Pearson_Correlation_Matrix_stressed)=1
if(is.positive.definite(Pearson_Correlation_Matrix_stressed)==FALSE){
  Pearson_Correlation_Matrix_stressed=bend(Pearson_Correlation_Matrix_stressed)
}
Uniform_gaussian=Uniform_gaussian_function(Sobol_data,t(chol(Pearson_Correlation_Matrix_stressed)))
Tau_matrix_gaussian=default_time(Uniform_gaussian,Lambda_array)
Fair_spread_corr_sensitivity_gaussian[i]=Fair_Spread(as.matrix(Tau_matrix_gaussian),Recovery)
##T Copula
KT_Correlation_Matrix_stressed=KT_Correlation_Matrix_Linear*(1+spread_array[i])
KT_Correlation_Matrix_stressed[KT_Correlation_Matrix_stressed>1]=1
KT_Correlation_Matrix_stressed[KT_Correlation_Matrix_stressed<-1]=-1
diag(KT_Correlation_Matrix_stressed)=1
if(is.positive.definite(KT_Correlation_Matrix_stressed)==FALSE){
  KT_Correlation_Matrix_stressed=bend(KT_Correlation_Matrix_stressed)
}
Uniform_studentt=Uniform_studentt_function(Sobol_data,Chi_Square,t(chol(KT_Correlation_Matrix_stressed)),degree_freedom)
Tau_matrix_studentt=default_time(Uniform_studentt,Lambda_array)
Fair_spread_corr_sensitivity_studentt[i]=Fair_Spread(as.matrix(Tau_matrix_studentt),Recovery)
}

##View the results
Fair_spread_corr_sensitivity_gaussian
Fair_spread_corr_sensitivity_studentt


#----------------------------------------
##Sensitivity to Recovery Rate
#----------------------------------------
Recovery_array=c(0.2,0.4,0.6,0.8)
Fair_spread_recovery_sensitivity_gaussian  <- as.data.frame(matrix(nrow=5,ncol=4))
colnames(Fair_spread_recovery_sensitivity_gaussian)=c("Rec: 0.2","Rec: 0.4","Rec: 0.6","Rec: 0.8")
Fair_spread_recovery_sensitivity_studentt  <- as.data.frame(matrix(nrow=5,ncol=4))
colnames(Fair_spread_recovery_sensitivity_studentt)=c("Rec: 0.2","Rec: 0.4","Rec: 0.6","Rec: 0.8")

#colnames(Fair_spread_recovery_sensitivity)=c("Rec:0.1","Rec:0.2","Rec:0.3","Rec:0.4","Rec:0.5","Rec:0.6","Rec:0.7","Rec:0.8","Rec:0.9")
Uniform_gaussian=Uniform_gaussian_function(Sobol_data,t(chol(Pearson_Correlation_Matrix)))
Uniform_studentt=Uniform_studentt_function(Sobol_data,Chi_Square,t(KT_Corr.chol),degree_freedom)
for (i in seq(1,4)) {
  Lambda_array=Lambda_calculation(Credit_Spreads,Recovery_array[i])
  ##Gaussian
  Tau_matrix_gaussian=default_time(Uniform_gaussian,Lambda_array)
  Fair_spread_recovery_sensitivity_gaussian[i]=Fair_Spread(as.matrix(Tau_matrix_gaussian),Recovery_array[i])
  ##Student T
  Tau_matrix_studentt=default_time(Uniform_studentt,Lambda_array)
  Fair_spread_recovery_sensitivity_studentt[i]=Fair_Spread(as.matrix(Tau_matrix_studentt),Recovery_array[i])
  }
##View results
Fair_spread_recovery_sensitivity_gaussian
Fair_spread_recovery_sensitivity_studentt

#-----------------------------------------
##Sensitivity to Credit Spread
#-----------------------------------------
Spread_array=c(0.1,0.2,0.3,0.4,0.5,1.0)
Fair_spread_credit_spread_sensitivity_gaussian  <- as.data.frame(matrix(nrow=5,ncol=6))
colnames(Fair_spread_credit_spread_sensitivity_gaussian)=c("Spread: 0.1","Spread: 0.2","Spread: 0.3","Spread: 0.4","Spread: 0.5","Spread: 1.0")
Fair_spread_credit_spread_sensitivity_studentt  <- as.data.frame(matrix(nrow=5,ncol=6))
colnames(Fair_spread_credit_spread_sensitivity_studentt)=c("Spread: 0.1","Spread: 0.2","Spread: 0.3","Spread: 0.4","Spread: 0.5","Spread: 1.0")
Uniform_gaussian=Uniform_gaussian_function(Sobol_data,t(chol(Pearson_Correlation_Matrix)))
Uniform_studentt=Uniform_studentt_function(Sobol_data,Chi_Square,t(KT_Corr.chol),degree_freedom)
for (i in seq(1,6)) {
  Credit_Spreads_stressed=Credit_Spreads*(1+Spread_array[i])
  Lambda_array=Lambda_calculation(Credit_Spreads_stressed,Recovery)
  ##Gaussian
  Tau_matrix_gaussian=default_time(Uniform_gaussian,Lambda_array)
  Fair_spread_credit_spread_sensitivity_gaussian[i]=Fair_Spread(as.matrix(Tau_matrix_gaussian),Recovery)
  ##Student T
  Tau_matrix_studentt=default_time(Uniform_studentt,Lambda_array)
  Fair_spread_credit_spread_sensitivity_studentt[i]=Fair_Spread(as.matrix(Tau_matrix_studentt),Recovery)
}
##View results
Fair_spread_credit_spread_sensitivity_gaussian
Fair_spread_credit_spread_sensitivity_studentt

#########################
#####Convergence/Stability test
#########################

#---------------------------------------
##Convergence function
#---------------------------------------
iterations=c(100,1000,10000,50000,100000)

###Converge using quasi random numbers (Sobol sequence)
Fair_spread_convergence_gaussian <-as.data.frame(matrix(nrow=5,ncol=5))
Fair_spread_convergence_studentt <-as.data.frame(matrix(nrow=5,ncol=5))
colnames(Fair_spread_convergence_gaussian)=c("Iter: 100","Iter: 1000","Iter: 10000","Iter: 50000","Iter: 100000")
colnames(Fair_spread_convergence_studentt)=c("Iter: 100","Iter: 1000","Iter: 10000","Iter: 50000","Iter: 100000")
for (i in seq(1,5)) {
  data=Sobol_function(iterations[i])
  ##Gaussian Copula
  Uniform_gaussian=Uniform_gaussian_function(data,t(chol(Pearson_Correlation_Matrix)))
  Tau_matrix_gaussian=default_time(Uniform_gaussian,Lambda_array)
  Fair_spread_convergence_gaussian[i]=Fair_Spread(as.matrix(Tau_matrix_gaussian),Recovery)
  ##T Copula
  Chi_Square=ChiSq_function(iterations[i],degree_freedom)
  Uniform_studentt=Uniform_studentt_function(data,Chi_Square,t(KT_Corr.chol),degree_freedom)
  Tau_matrix_studentt=default_time(Uniform_studentt,Lambda_array)
  Fair_spread_convergence_studentt[i]=Fair_Spread(as.matrix(Tau_matrix_studentt),Recovery)
}
##View results
Fair_spread_convergence_gaussian
Fair_spread_convergence_studentt

###Converge using pseudo random numbers (Sobol sequence)
Fair_spread_convergence_gaussian_pseudo <-as.data.frame(matrix(nrow=5,ncol=5))
Fair_spread_convergence_studentt_pseudo <-as.data.frame(matrix(nrow=5,ncol=5))
colnames(Fair_spread_convergence_gaussian_pseudo)=c("Iter: 100","Iter: 1000","Iter: 10000","Iter: 50000","Iter: 100000")
colnames(Fair_spread_convergence_studentt_pseudo)=c("Iter: 100","Iter: 1000","Iter: 10000","Iter: 50000","Iter: 100000")
for (i in seq(1,5)) {
  data=Random_number_function(iterations[i])
  ##Gaussian Copula
  Uniform_gaussian=Uniform_gaussian_function(data,t(chol(Pearson_Correlation_Matrix)))
  Tau_matrix_gaussian=default_time(Uniform_gaussian,Lambda_array)
  Fair_spread_convergence_gaussian_pseudo[i]=Fair_Spread(as.matrix(Tau_matrix_gaussian),Recovery)
  ##T Copula
  Chi_Square=ChiSq_function(iterations[i],degree_freedom)
  Uniform_studentt=Uniform_studentt_function(data,Chi_Square,t(KT_Corr.chol),degree_freedom)
  Tau_matrix_studentt=default_time(Uniform_studentt,Lambda_array)
  Fair_spread_convergence_studentt_pseudo[i]=Fair_Spread(as.matrix(Tau_matrix_studentt),Recovery)
}
##View results
Fair_spread_convergence_gaussian_pseudo
Fair_spread_convergence_studentt_pseudo
