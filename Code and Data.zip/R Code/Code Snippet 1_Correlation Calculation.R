#### Pearson and Kendall Tau correlations for Gaussian and T-Copula

##### Read 5-years stock data
setwd("C:/Users/aviks/Documents/CQF/Final Project/Submission/Data/Asset Prices for Correlation")

GOOG_stock_return=read.csv("GOOG.csv",header=TRUE,sep=",")
AMZN_stock_return=read.csv("AMZN.csv",header=TRUE,sep=",")
MSFT_stock_return=read.csv("MSFT.csv",header=TRUE,sep=",")
AAPL_stock_return=read.csv("AAPL.csv",header=TRUE,sep=",")
NFLX_stock_return=read.csv("NFLX.csv",header=TRUE,sep=",")


### Histogram plot of the stock log return 
hist(GOOG_stock_return$Log.Return,20)
hist(AMZN_stock_return$Log.Return,20)
hist(MSFT_stock_return$Log.Return,20)
hist(AAPL_stock_return$Log.Return,20)
hist(NFLX_stock_return$Log.Return,20)

### Check for Normality 

##Shapiro Wilk Test
shapiro.test(GOOG_stock_return$Log.Return)
shapiro.test(AMZN_stock_return$Log.Return)
shapiro.test(MSFT_stock_return$Log.Return)
shapiro.test(AAPL_stock_return$Log.Return)
shapiro.test(NFLX_stock_return$Log.Return)

###Normality tests as part of LambertW package
library(LambertW)
test_norm(GOOG_stock_return$Log.Return)
test_norm(AMZN_stock_return$Log.Return)
test_norm(MSFT_stock_return$Log.Return)
test_norm(AAPL_stock_return$Log.Return)
test_norm(NFLX_stock_return$Log.Return)

## Transformation to uniform distribution using empirical distribution function

ecdf_transformation = function(X) {
  fn = ecdf(X) 
  U = fn(X)
  return(U)
}

library(dplyr)

## Transform Google return and check for normality
GOOG_stock_return$Log.Return_uniform=ecdf_transformation(GOOG_stock_return$Log.Return)
GOOG_stock_return$Log.Return_norm=as.numeric(qnorm(GOOG_stock_return$Log.Return_uniform))
GOOG_stock_return=GOOG_stock_return %>% filter(Log.Return_norm!="Inf")
hist(GOOG_stock_return$Log.Return_uniform,20)
hist(GOOG_stock_return$Log.Return_norm,20)


## Transform Amazon return and check for normality
AMZN_stock_return$Log.Return_uniform=ecdf_transformation(AMZN_stock_return$Log.Return)
AMZN_stock_return$Log.Return_norm=as.numeric(qnorm(AMZN_stock_return$Log.Return_uniform))
AMZN_stock_return=AMZN_stock_return %>% filter(Log.Return_norm!="Inf")
hist(AMZN_stock_return$Log.Return_uniform,20)
hist(AMZN_stock_return$Log.Return_norm,20)

## Transform Microsoft return and check for normality
MSFT_stock_return$Log.Return_uniform=ecdf_transformation(MSFT_stock_return$Log.Return)
MSFT_stock_return$Log.Return_norm=as.numeric(qnorm(MSFT_stock_return$Log.Return_uniform))
MSFT_stock_return=MSFT_stock_return %>% filter(Log.Return_norm!="Inf")
hist(MSFT_stock_return$Log.Return_uniform,20)
hist(MSFT_stock_return$Log.Return_norm,20)

## Transform Apple return and check for normality
AAPL_stock_return$Log.Return_uniform=ecdf_transformation(AAPL_stock_return$Log.Return)
AAPL_stock_return$Log.Return_norm=as.numeric(qnorm(AAPL_stock_return$Log.Return_uniform))
AAPL_stock_return=AAPL_stock_return %>% filter(Log.Return_norm!="Inf")
hist(AAPL_stock_return$Log.Return_uniform,20)
hist(AAPL_stock_return$Log.Return_norm,20)

## Transform Netflix return and check for normality
NFLX_stock_return$Log.Return_uniform=ecdf_transformation(NFLX_stock_return$Log.Return)
NFLX_stock_return$Log.Return_norm=as.numeric(qnorm(NFLX_stock_return$Log.Return_uniform))
NFLX_stock_return=NFLX_stock_return %>% filter(Log.Return_norm!="Inf")
hist(NFLX_stock_return$Log.Return_uniform,20)
hist(NFLX_stock_return$Log.Return_norm,20)

###scatter plot
plot(AMZN_stock_return$Log.Return_norm,NFLX_stock_return$Log.Return_norm)
abline(lm(NFLX_stock_return$Log.Return_norm ~ AMZN_stock_return$Log.Return_norm), col = "blue")

plot(MSFT_stock_return$Log.Return_norm,AAPL_stock_return$Log.Return_norm)
abline(lm(AAPL_stock_return$Log.Return_norm ~ MSFT_stock_return$Log.Return_norm), col = "blue")

plot(AAPL_stock_return$Log.Return_norm,NFLX_stock_return$Log.Return_norm)
abline(lm(NFLX_stock_return$Log.Return_norm ~ AAPL_stock_return$Log.Return_norm), col = "blue")

####Input data for Pearson correlation matrix
Corr_input=cbind(GOOG_stock_return$Log.Return_norm,AMZN_stock_return$Log.Return_norm,MSFT_stock_return$Log.Return_norm,AAPL_stock_return$Log.Return_norm,NFLX_stock_return$Log.Return_norm)

#### Compute the Pearson Correlation Matrix for Gaussian Copula
Pearson_Correlation_Matrix=cor(Corr_input, method = "pearson")
Pearson_Correlation_Matrix
library(matrixcalc)
is.positive.definite(Pearson_Correlation_Matrix, tol=1e-8)

## Cholesky decomposition of Pearson correlation matrix
Pearson_Corr.chol <- chol(Pearson_Correlation_Matrix)
t(Pearson_Corr.chol)
library(xlsx)
write.xlsx(Pearson_Correlation_Matrix, file="Pearson_Corr.xlsx", sheetName = "Pearson", 
           col.names = TRUE, row.names = TRUE, append = FALSE)
write.xlsx(t(Pearson_Corr.chol), file="Pearson_Corr.xlsx", sheetName = "Cholesky", 
           col.names = TRUE, row.names = TRUE, append = TRUE)

####Input data for Kendall Tau correlation matrix
KT_Corr_input=cbind(GOOG_stock_return$Log.Return,AMZN_stock_return$Log.Return,MSFT_stock_return$Log.Return,AAPL_stock_return$Log.Return,NFLX_stock_return$Log.Return)

#### Compute the Kendall Tau Correlation Matrix for t-Student Copula
KT_Correlation_Matrix=cor(KT_Corr_input, method = "kendal")
KT_Correlation_Matrix

###Linearise the Kendall Tau matrix
KT_Correlation_Matrix_Linear=sin(0.5*pi*KT_Correlation_Matrix)
KT_Correlation_Matrix_Linear
is.positive.definite(KT_Correlation_Matrix_Linear, tol=1e-8)

## Cholesky decomposition of Kendall Tau correlation matrix
KT_Corr.chol <- chol(KT_Correlation_Matrix_Linear)
t(KT_Corr.chol)
library(xlsx)
write.xlsx(KT_Correlation_Matrix_Linear, file="KT_Corr.xlsx", sheetName = "Kendall", 
           col.names = TRUE, row.names = TRUE, append = FALSE)
write.xlsx(t(KT_Corr.chol), file="KT_Corr.xlsx", sheetName = "Cholesky", 
           col.names = TRUE, row.names = TRUE, append = TRUE)
